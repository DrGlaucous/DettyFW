I don't know the best way to actually develop a library in platformIO, so I'm setting up a mini project in here to do my work.
Final changes will be put in the parent directory. Ignore this one.


ESPDshot-Testing is the sub-project that I do actual library development in

ComputerDebug is where I run bits of the code on a PC so I can step through it and debug.