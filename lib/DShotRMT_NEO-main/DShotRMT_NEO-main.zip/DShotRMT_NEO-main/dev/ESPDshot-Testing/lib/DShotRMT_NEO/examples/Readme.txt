Look inside the dev folder to see an example on how to use this library (it's pretty easy)

(p.s. yes, I know the readme inside the dev folder tells you to ignore it, but ignore the ignore statement if you want to see the example)